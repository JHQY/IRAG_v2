# ingestion/indexer.py
from ingestion.loader import scan_documents
from ingestion.parser import parse_pdf
from ingestion.chunker import chunk_blocks
from embedding.embedder import Embedder
from storage.milvus_store import MilvusVectorStore
from config.settings import settings
from tqdm import tqdm

# def build_index(source_dir="sourcepdf"):
#     """
#     构建保险知识库索引：
#     1. 扫描所有文件
#     2. 抽取文字 + 表格（带上下文）
#     3. 对文字内容分块
#     4. 嵌入 + 写入 Milvus
#     """
#     print("🚀 开始构建索引 ...")
#     docs = scan_documents(source_dir)
#     if not docs:
#         print("⚠️ 没有找到可索引的文件。")
#         return

#     embedder = Embedder()
#     store = MilvusVectorStore()
#     total_chunks = 0

#     for doc in tqdm(docs, desc="索引进度"):
#         try:
#             parsed_blocks = parse_pdf(doc["path"])
#             # print(f"📄 解析完成：{doc['path']}，提取到 {len(parsed_blocks)} 个内容块。")
#             # print(f"预览内容块：{parsed_blocks[:2]}")  # 打印前两个内容块以供调试
#             if not parsed_blocks:
#                 print(f"⚠️ 文件无有效内容：{doc['path']}")
#                 continue

#             for block in parsed_blocks:
#                 # content = block.get("text", "").strip()
#                 # modality = block.get("modality", "text")
#                 # page = block.get("page", 0)
                

#                 # 跳过空块
#                 if not content:
#                     continue

#                 # 仅文本进行分块；表格保持整块
#                 if modality == "text":
#                     chunks = chunk_blocks(parsed_blocks)
#                 else:
#                     chunks = [content]
                
#                 for c in chunks:
#                     emb = embedder.embed_text([c])[0]
#                     meta = {
#                         **doc["metadata"],
#                         "page": page,
#                         "modality": modality
#                     }
#                     store.add([emb], [Chunk(c, meta)])
#                     total_chunks += 1

#         except Exception as e:
#             print(f"❌ 文件处理失败: {doc['path']} ({e})")

#     print(f"✅ 索引完成，共写入 {total_chunks} 个文本块。")

def build_index(source_dir="sourcepdf"):
    print("🚀 开始构建 IRAG_MM 多模态索引 ...")

    docs = scan_documents(source_dir)
    if not docs:
        print("⚠️ 没有找到可索引的文件。")
        return

    embedder = Embedder()
    store = MilvusVectorStore()

    total = 0
    batch_records = []
    batch_size = 100

    for doc in tqdm(docs, desc="索引进度"):
        try:
            blocks = parse_pdf(doc["path"])
            if not blocks:
                print(f"⚠️ 无有效内容：{doc['path']}")
                continue

            # 注入 metadata
            for b in blocks:
                b.setdefault("metadata", {})
                b["metadata"].update({
                    "source": doc.get("path", ""),
                    "company": doc.get("company", ""),
                    "category": doc.get("category", ""),
                    "page_number": b["metadata"].get("page_number"),
                    "modality": b.get("modality")
                })

            chunks = chunk_blocks(blocks, max_length=500, overlap=50)

            # ------------------------------------------------------
            # 逐 chunk 写入
            # ------------------------------------------------------
            for c in chunks:
                modality = c.get("modality")
                meta = c.get("metadata", {})

                text_value = None
                table_json = None
                text_vec = None
                table_vec = None

                # -------------------------
                # 文本块
                # -------------------------
                if modality == "text":
                    raw_text = (c.get("text") or "").strip()
                    if not raw_text:
                        continue
                    text_value = text_value or ""
                    text_vec = embedder.embed_text([raw_text])[0]

                # -------------------------
                # 表格块
                # -------------------------
                elif modality == "table":
                    table = c.get("table")
                    if not table:
                        continue

                    header = table.get("header", [])
                    rows = table.get("rows", [])

                    # TAPAS embedding
                    table_vec = embedder.embed_table(header, rows)
                    table_json = table

                    # ❌ 不再进行文本增强
                    text_value = None
                    text_vec = None

                else:
                    continue

                # 至少要有一个向量
                if text_vec is None and table_vec is None:
                    continue

                batch_records.append({
                    "modality": modality,
                    "text": text_value,
                    "table_json": table_json,
                    "text_vec": text_vec,
                    "table_vec": table_vec,
                    "metadata": meta
                })

                # 批量写入
                if len(batch_records) >= batch_size:
                    store.add_records(batch_records)
                    total += len(batch_records)
                    batch_records = []

        except Exception as e:
            print(f"❌ 文件失败：{doc['path']} ({e})")

    if batch_records:
        store.add_records(batch_records)
        total += len(batch_records)

    print(f"🎉 多模态索引构建完成，共写入 {total} 个块。")
