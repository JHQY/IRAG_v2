from pymilvus import connections, utility

connections.connect("default", host="127.0.0.1", port="19530")

if utility.has_collection("IRAG_MM"):
    utility.drop_collection("IRAG_MM")
    print("Dropped old IRAG_MM")
else:
    print("IRAG_MM does not exist")
