'''Build index script placeholder'''
from ingestion.indexer import build_index
import sys, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

if __name__ == "__main__":
    build_index("sourcepdf")