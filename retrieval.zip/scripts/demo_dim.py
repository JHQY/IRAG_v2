from embedding.embedder import Embedder
e = Embedder()
v = e.embed_text(["测试"])[0]
print(type(v), v.shape)
